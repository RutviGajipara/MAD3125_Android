package com.jk.sirra;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class MnualActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mnual);


        WebView webManual = findViewById(R.id.webManual);
        webManual.loadUrl("http://www.google.com");
        webManual.loadUrl("file:///android_asset/ParkingManual.html");
    }
}
