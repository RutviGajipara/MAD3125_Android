package com.jk.sirra;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import java.lang.ref.SoftReference;
import java.util.Calendar;

public class NewParingActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {
 TextView txtAmount, txtDateTime,edtCarPlate;
 Spinner spnLot,spnSpot, spnPayment, spnCarCompany;
 Button btnAddParking;
 RadioButton rdo1,rdo2,rdo3,rdo4;
 int ParkingRate[] = {10,20,30,100};
 String[] lots = {"A","B","C","D","E"};
 String[] spots = {"1","2","3","4","5"};
 String[] paymentMethods = {"Credit card","Debit Card","master Card","American Express"};
 String[] companyName ={"BMW","Audi","Jaguar","Lexus","Mercedes"};
 int[] logos = {R.drawable.img_bmw,R.drawable.img_audi,R.drawable.img_jaguar,R.drawable.img_lexus,R.drawable.img_mercedes};


String selectedLot,selectedSpot,selectedPayment,selectedCompany;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_paring);

       edtCarPlate = findViewById(R.id.edtCarPlate);
        txtAmount = findViewById(R.id.txtAmount);
        txtAmount.setText("$" + ParkingRate[0]);
        txtDateTime = findViewById(R.id.txtDateTime);
        txtDateTime.setText(Calendar.getInstance().getTime().toString());

        btnAddParking = findViewById(R.id.btnAddParking);
        btnAddParking.setOnClickListener(this);

        rdo1 = findViewById(R.id.rdo1);
        rdo1.setOnClickListener(this);

        rdo2 = findViewById(R.id.rdo2);
        rdo2.setOnClickListener(this);

        rdo3 = findViewById(R.id.rdo3);
        rdo3.setOnClickListener(this);

        rdo4 = findViewById(R.id.rdo4);
        rdo4.setOnClickListener(this);

        spnLot = findViewById(R.id.spnLot);
        ArrayAdapter lotAdapter = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item, lots);
        spnLot.setAdapter(lotAdapter);
        spnLot.setOnItemSelectedListener(this);

        spnSpot = findViewById(R.id.spnSpot);
        ArrayAdapter spotAdapter = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,spots);
        spnSpot.setAdapter(spotAdapter);
        spnSpot.setOnItemSelectedListener(this);

        spnCarCompany = findViewById(R.id.spnCarCompany);
        carCompanyAdapter companyAdapter = new carCompanyAdapter(getApplicationContext(),logos,companyName);
        spnCarCompany.setAdapter(companyAdapter);
        spnCarCompany.setOnItemSelectedListener(this);

        spnPayment = findViewById(R.id.spnPayment);
        ArrayAdapter paymentdapter = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,paymentMethods);
        spnPayment.setAdapter(paymentdapter);
        spnPayment.setOnItemSelectedListener(this);

    }
    @Override
    public void onClick(View view)
    {
        if(view.getId() == rdo1.getId())
        {
            txtAmount.setText("$" + ParkingRate[0]);
        }
        else if(view.getId() == rdo2.getId())
        {
            txtAmount.setText("$" + ParkingRate[1]);
        }
        else if(view.getId() == rdo3.getId())
        {
            txtAmount.setText("$" + ParkingRate[2]);
        }else if(view.getId() == rdo4.getId())
        {
            txtAmount.setText("$" + ParkingRate[3]);
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
        if(adapterView.getId() == spnLot.getId())
        {
         selectedLot = lots[position];
        }else if(adapterView.getId() == spnSpot.getId())
        {
            selectedSpot = spots[position];
        }
        else if(adapterView.getId() == spnPayment.getId())
        {
            selectedPayment = paymentMethods[position];
        }
        else if(adapterView.getId() == spnCarCompany.getId())
        {
            selectedCompany = companyName[position];
        }


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
