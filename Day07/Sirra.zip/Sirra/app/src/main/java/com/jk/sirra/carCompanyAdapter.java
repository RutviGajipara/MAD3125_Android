package com.jk.sirra;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class carCompanyAdapter extends BaseAdapter {
    int[] logos;
    String[] companyName;
    Context context;
    LayoutInflater inflater;

    carCompanyAdapter (Context context, int[] logos, String[] companyName)
    {
        this.context = context;
        this.logos = logos;
        this.companyName  = companyName;
        inflater = LayoutInflater.from(context);
    }
    @Override
    public int getCount() {
      return companyName.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.carcompany_spinner_item,null);
        ImageView imgLogo = convertView.findViewById(R.id.imgLogo);
        imgLogo.setImageResource(this.logos[position]);
        TextView txtCompany = convertView.findViewById(R.id.txtCompany);
        txtCompany.setText(this.companyName[position]);
        return convertView;
    }
}
