package com.jk.sirra;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class ReportAdapter extends BaseAdapter {
    LayoutInflater inflater;
    Context context;
    String[] carPlates = {"ABCD123", "DFDF535", "FDFE7584" };
    String[] amount = {"$10", "$20", "$30" };
    String[] lots = {"A", "R", "F" };
    String[] spots = {"101", "202", "303" };
    String[] DateTime = {"06-27-2-18 12:30PM", "06-27-2-18 1:30PM", "06-27-2-18 2:30PM" };
    ReportAdapter(Context context) {

        this.context = context;
        inflater = LayoutInflater.from(context);
    }

        @Override
        public int getCount () {
            return carPlates.length;
        }

        @Override
        public Object getItem ( int position){
            return null;
        }

        @Override
        public long getItemId ( int position){
            return 0;
        }

        @Override
        public View getView (final int position, View view, ViewGroup viewGroup){
        view = inflater.inflate(R.layout.list_report_item,null);

            TextView txtCarPlate = view.findViewById(R.id.txtCarPlate);
            txtCarPlate.setText(carPlates[position]);

            TextView txtAmount = view.findViewById(R.id.txtAmount);
            txtAmount.setText(amount[position]);

            TextView txtDateTime = view.findViewById(R.id.txtDateTime);
            txtDateTime.setText(DateTime[position]);

            TextView txtLot = view.findViewById(R.id.txtLot);
            txtLot.setText(lots[position]);

            TextView txtSpots = view.findViewById(R.id.txtSpot);
            txtSpots.setText(spots[position]);

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(context,"Item" + position + "selected",Toast.LENGTH_SHORT).show();
                }
            });
            return view;
        }
    }
