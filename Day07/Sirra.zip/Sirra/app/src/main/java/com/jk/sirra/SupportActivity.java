package com.jk.sirra;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SupportActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnCall, btnEmail, btnSMS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support);

        btnCall = findViewById(R.id.btnCall);
        btnCall.setOnClickListener(this);
        btnSMS = findViewById(R.id.btnSMS);
        btnSMS.setOnClickListener(this);
        btnEmail = findViewById(R.id.btnEmail);
        btnEmail.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnCall:
                makeCall();
                break;
            case R.id.btnSMS:

                sendSMS();
                break;
            case R.id.btnEmail:

                sendEmail();
                break;

        }
    }

    private void makeCall() {
        Intent callintent = new Intent(Intent.ACTION_CALL);
        callintent.setData(Uri.parse("tel : 1234567892"));
        if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(getApplicationContext(), "call permission denied", Toast.LENGTH_SHORT).show();
        }
        startActivity(callintent);
    }

    private void sendSMS() {
        Intent smsintent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto : 1234567891"));
        smsintent.putExtra("sms_body", "This is a text message");
        if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(getApplicationContext(), "SMS permission denied", Toast.LENGTH_SHORT).show();
        }
        startActivity(smsintent);

    }

    private void sendEmail() {
        Intent emailintent = new Intent(Intent.ACTION_SEND);
        emailintent.putExtra(Intent.EXTRA_EMAIL, new String[] {"r.g@gmail.com", "a.t@gmail.com", "t.u@gmail.com" });
        emailintent.putExtra(Intent.EXTRA_SUBJECT, "Test message");
        emailintent.putExtra(Intent.EXTRA_TEXT, "This is a test email");
        emailintent.setType("*/*");
        startActivity(Intent.createChooser(emailintent, "select emeil profile"));
    }
}
